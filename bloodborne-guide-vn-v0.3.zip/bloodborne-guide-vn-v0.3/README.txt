Bloodborne Guide VN v0.3

Cach mo:
1. Giai nen file ZIP.
2. Giu nguyen thu muc assets ben canh index.html.
3. Mo index.html bang trinh duyet.

Anh/font da duoc tach khoi HTML de giam kich thuoc file index.html.
